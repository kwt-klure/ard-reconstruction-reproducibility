#!/usr/bin/env python3
"""Verify saved fresh ARD arrays and compare with the archived same-seed study.

No estimator is executed, and the input directories are read-only. Creation
refuses to replace any output. --verify-only rederives all numerical checks
without writing. The optional baseline is needed only for comparison.json.

Pure scoring, trace diagnostics and pairing formulas are adapted from the
baseline package's verify_saved.py and verify_auc.py; they do not call the
experiment's scoring, sampling or optimization functions.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import itertools
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
import numpy as np

SEEDS = [101, 202, 303, 404, *range(1001, 1037)]
KS = [4, 8]
MODELS = {"Bayes_circle": "bayes_P", "Nuclear_probability": "nuclear_P", "Density": "density_P"}
METRICS = ("auc", "probability_rmse", "ard_rmse")
SCALARS = ("alpha", "poisson_loglik", "ard_mse")
AUC_MODELS = {"True_P": "true_P", "Count_product": None, **MODELS}
AUC_PAIRS = (("Count_product", "Nuclear_probability"), ("Count_product", "True_P"), ("Bayes_circle", "True_P"))
RUNTIME_KEYS = {"python", "numpy", "platform", "thread_environment", "total_seconds"}
SCOPE = "Fresh execution of the original forty seeds and both K designs. These are the same forty independent graphs, not forty additional independent replicates. No selective rerun or exclusion."


def require(condition, message):
    if not condition:
        raise ValueError(message)


def close(actual, expected, message, atol=1e-12, rtol=1e-11):
    require(bool(np.isfinite(actual)) and bool(np.isfinite(expected)) and
            bool(np.isclose(actual, expected, atol=atol, rtol=rtol)),
            f"{message}: {actual!r} != {expected!r}")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def manifest_digest(entries):
    return hashlib.sha256(json.dumps(entries, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def auc_pair(labels, scores):
    positive, negative = scores[labels == 1], scores[labels == 0]
    require(len(positive) > 0 and len(negative) > 0, "AUC needs both classes")
    differences = positive[:, None] - negative[None, :]
    return float(np.mean((differences > 0) + 0.5 * (differences == 0)))


def auc_rank(labels, scores):
    order = np.argsort(scores, kind="stable")
    ranks = np.empty(len(scores), dtype=float)
    first = 0
    while first < len(scores):
        last = first + 1
        while last < len(scores) and scores[order[last]] == scores[order[first]]:
            last += 1
        ranks[order[first:last]] = (first + 1 + last) / 2.0
        first = last
    positives, negatives = int(np.count_nonzero(labels == 1)), int(np.count_nonzero(labels == 0))
    require(positives > 0 and negatives > 0, "AUC needs both classes")
    return float((ranks[labels == 1].sum() - positives * (positives + 1) / 2) / (positives * negatives))


def score(estimate, y, b, a, truth):
    upper = np.triu_indices(len(b), 1)
    return {"auc": auc_rank(a[upper], estimate[upper]),
            "probability_rmse": float(np.sqrt(np.mean((estimate[upper] - truth[upper]) ** 2))),
            "ard_rmse": float(np.sqrt(np.mean((estimate @ b - y) ** 2)))}


def diagnostic(chains):
    """Classic split R-hat and initial-positive-sequence ESS, not rank-normalized."""
    m, draws = chains.shape
    half = draws // 2
    split = np.concatenate((chains[:, :half], chains[:, -half:]), axis=0)
    within = np.var(split, axis=1, ddof=1).mean()
    between = half * np.var(split.mean(axis=1), ddof=1)
    variance = (half - 1) / half * within + between / half
    require(within > 0 and variance > 0, "degenerate scalar chain")
    centered = split - split.mean(axis=1, keepdims=True)
    covariance = np.array([np.mean(np.sum(centered[:, :half-lag] * centered[:, lag:], axis=1) / half)
                           for lag in range(half)])
    rho = 1 - (within - covariance) / variance
    rho[0] = 1.0
    pairs = []
    for lag in range(0, half - 1, 2):
        pair = rho[lag] + rho[lag + 1]
        if pair < 0:
            break
        pairs.append(min(pair, pairs[-1]) if pairs else pair)
    tau = max(-1 + 2 * sum(pairs), 1)
    return {"split_rhat": float(np.sqrt(variance / within)),
            "ess_initial_positive": float(min(m * 2 * half / tau, m * 2 * half))}


def matrix_constraints(p, label):
    require(p.shape == (40, 40), label + " shape")
    require(np.isfinite(p).all(), label + " finite")
    require(np.allclose(p, p.T, atol=1e-10, rtol=0), label + " symmetry")
    require(np.all(np.diag(p) == 0), label + " zero diagonal")
    require(np.all((p >= 0) & (p <= 1)), label + " probability bounds")


def describe(values):
    values = np.asarray(values, dtype=float)
    sd = float(values.std(ddof=1))
    return {"n": len(values), "mean": float(values.mean()), "sd": sd,
            "mcse": sd / math.sqrt(len(values))}


def paired_summaries(records):
    output = {}
    for cohort, seeds in (("original4", SEEDS[:4]), ("extension36", SEEDS[4:]), ("all40", SEEDS)):
        for k in KS:
            for model in MODELS:
                for metric in METRICS:
                    output[cohort, str(k), model, metric] = describe([records[k, s, model][metric] for s in seeds])
            for left, right in itertools.combinations(MODELS, 2):
                for metric in METRICS:
                    output[cohort, str(k), f"{left} minus {right}", metric] = describe(
                        [records[k, s, left][metric] - records[k, s, right][metric] for s in seeds])
        for model in MODELS:
            for metric in METRICS:
                output[cohort, "8 minus 4", model, metric] = describe(
                    [records[8, s, model][metric] - records[4, s, model][metric] for s in seeds])
    return output


def unique(rows, fields):
    result = {tuple(r[f] for f in fields): r for r in rows}
    require(len(result) == len(rows), "duplicate record " + repr(fields))
    return result


def compare_values(actual, expected):
    """Report every unequal JSON leaf, plus exact/max-error statistics."""
    differences, errors = [], []
    leaves = 0
    def visit(a, b, trail):
        nonlocal leaves
        if isinstance(a, dict) and isinstance(b, dict):
            for key in sorted(set(a) | set(b)):
                if key not in a or key not in b:
                    differences.append({"path": trail + "/" + str(key), "fresh": a.get(key), "baseline": b.get(key), "kind": "missing key"})
                else:
                    visit(a[key], b[key], trail + "/" + str(key))
        elif isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
            for i, (x, y) in enumerate(zip(a, b)):
                visit(x, y, trail + f"/{i}")
        else:
            leaves += 1
            if a != b or type(a) is not type(b):
                entry = {"path": trail, "fresh": a, "baseline": b}
                if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool) and not isinstance(b, bool):
                    entry["absolute_error"] = abs(a - b)
                    errors.append(abs(a - b))
                differences.append(entry)
    visit(actual, expected, "root")
    return {"exact_equal": not differences, "leaves_compared": leaves,
            "different_leaves": len(differences), "max_absolute_error": max(errors, default=0.0),
            "differences": differences}


def require_recomputed_equal(actual, expected, trail="root"):
    """Tight numerical tolerance for portable NumPy verification; exact structure."""
    if isinstance(actual, dict):
        require(isinstance(expected, dict) and set(actual) == set(expected), trail + " keys")
        for key in actual:
            require_recomputed_equal(actual[key], expected[key], trail + "/" + str(key))
    elif isinstance(actual, list):
        require(isinstance(expected, list) and len(actual) == len(expected), trail + " length")
        for i, (a, b) in enumerate(zip(actual, expected)):
            require_recomputed_equal(a, b, trail + f"/{i}")
    elif isinstance(actual, float):
        require(isinstance(expected, (int, float)) and not isinstance(expected, bool), trail + " numeric type")
        close(actual, expected, trail)
    else:
        require(type(actual) is type(expected) and actual == expected, trail + " value")


def verify_arrays(results_dir, protocol):
    data = read_json(results_dir / "results.json")
    metadata = data["metadata"]
    fixed = {"seeds": SEEDS, "n": 40, "k": KS, "dgp_alpha": -2.8,
             "fixed_zeta": 1.5, "nuclear_penalty": 1.0, "chains": 2,
             "warmup": 400, "draws": 800}
    for key, expected in fixed.items():
        require(protocol[key] == expected, "fixed contract " + key)
        alias = {"warmup": "warmup_per_chain", "draws": "kept_per_chain"}.get(key, key)
        require(metadata[alias] == expected, "fresh metadata " + alias)
    require(set(metadata) == set(fixed) - {"warmup", "draws"} | {"warmup_per_chain", "kept_per_chain"} | RUNTIME_KEYS, "metadata schema")
    require(all(metadata["thread_environment"].get(name) == "1" for name in
                ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")), "thread settings")
    require(np.isfinite(metadata["total_seconds"]) and metadata["total_seconds"] > 0, "execution duration")
    records = unique(data["runs"], ("k", "seed", "model"))
    require(set(records) == set(itertools.product(KS, SEEDS, MODELS)), "240 complete method records")
    diagnostics = unique(data["diagnostics"], ("k", "seed"))
    require(set(diagnostics) == set(itertools.product(KS, SEEDS)), "80 diagnostic records")
    expected_npz = {f"run_k{k}_seed{s}.npz" for k, s in itertools.product(KS, SEEDS)}
    require({p.name for p in results_dir.glob("*.npz")} == expected_npz, "80 array files")
    csv_rows = read_csv(results_dir / "runs.csv")
    csv_records = {(int(row["k"]), int(row["seed"]), row["model"]): row for row in csv_rows}
    require(len(csv_rows) == len(csv_records) == 240, "runs.csv normalized key uniqueness/count")
    require(set(csv_records) == set(records), "runs.csv complete normalized key set")
    for key, row in csv_records.items():
        require(key in records and int(row["n"]) == 40, "runs.csv key")
        for name in (*METRICS, "seconds"):
            close(float(row[name]), records[key][name], "runs.csv " + name)
    arrays_by_key, recomputed, nested = {}, {}, {}
    scalar_diagnostics, mcmc_failures, admm_failures, auc_rows = [], [], [], []
    max_metric_error = max_scalar_error = max_objective_error = max_auc_error = 0.0
    for k, seed in itertools.product(KS, SEEDS):
        label = f"K={k}, seed={seed}"
        with np.load(results_dir / f"run_k{k}_seed{seed}.npz", allow_pickle=False) as archive:
            arrays = {key: archive[key] for key in archive.files}
        arrays_by_key[k, seed] = arrays
        require(set(arrays) == {"Y", "B", "hidden_A", "true_P", "bayes_P", "nuclear_P", "density_P", "bayes_traces"}, label + " array schema")
        require(all(np.isfinite(a).all() for a in arrays.values()), label + " finite arrays")
        y, b, a, truth = (arrays[key] for key in ("Y", "B", "hidden_A", "true_P"))
        require(y.shape == b.shape == (40, k), label + " observation shapes")
        require(np.array_equal(b, np.eye(k)[np.arange(40) % k]), label + " roster")
        matrix_constraints(a, label + " graph")
        matrix_constraints(truth, label + " truth")
        require(np.all((a == 0) | (a == 1)), label + " binary graph")
        require(np.array_equal(y, a @ b), label + " Y=AB")
        require(np.all(y >= 0) and np.all(y == np.floor(y)), label + " integer counts")
        require(np.all(y <= b.sum(axis=0)[None, :] - b), label + " count limits")
        require(np.array_equal(b.T @ y, (b.T @ y).T), label + " reciprocity")
        require(np.array_equal(y.sum(axis=1), a.sum(axis=1)), label + " row degrees")
        require(y.sum() == 2 * np.triu(a, 1).sum(), label + " edge totals")
        if k == 4:
            nested[seed] = (a, truth, y, b)
        else:
            previous = nested[seed]
            require(np.array_equal(a, previous[0]) and np.array_equal(truth, previous[1]), label + " matched graph/truth")
            require(np.array_equal(y[:, :4] + y[:, 4:], previous[2]), label + " nested counts")
            require(np.array_equal(b[:, :4] + b[:, 4:], previous[3]), label + " nested rosters")
        density = np.full((40, 40), y.sum() / (40 * 39))
        np.fill_diagonal(density, 0)
        require(np.array_equal(density, arrays["density_P"]), label + " density baseline")
        for model, name in MODELS.items():
            matrix_constraints(arrays[name], label + " " + model)
            key = k, seed, model
            require(records[key]["n"] == 40 and np.isfinite(records[key]["seconds"]) and records[key]["seconds"] >= 0, label + " method metadata")
            recomputed[key] = score(arrays[name], y, b, a, truth)
            for metric in METRICS:
                close(recomputed[key][metric], records[key][metric], label + " " + model + " " + metric)
                max_metric_error = max(max_metric_error, abs(recomputed[key][metric] - records[key][metric]))
        traces = arrays["bayes_traces"]
        require(traces.shape == (2, 800, 3), label + " scalar trace shape")
        bayes = diagnostics[k, seed]["bayes"]
        local = {}
        for j, name in enumerate(SCALARS):
            value = diagnostic(traces[:, :, j])
            local[name] = value
            scalar_diagnostics.append(value)
            for metric, actual in value.items():
                close(actual, bayes[name][metric], label + " " + name + " " + metric)
                max_scalar_error = max(max_scalar_error, abs(actual - bayes[name][metric]))
        passed = all(v["split_rhat"] < 1.05 and v["ess_initial_positive"] >= 100 for v in local.values())
        require(bayes["screen_pass"] is passed, label + " MCMC flag")
        if not passed:
            mcmc_failures.append({"k": k, "seed": seed, "diagnostics": bayes})
        acceptance = np.asarray(bayes["acceptance_alpha_angle"])
        scales = np.asarray(bayes["final_proposal_scales"])
        require(acceptance.shape == (2, 2) and np.all((acceptance >= 0) & (acceptance <= 1)), label + " acceptance range")
        require(scales.shape == (2, 2) and np.all((scales >= 0.02) & (scales <= 3)), label + " proposal scales")
        nuclear = diagnostics[k, seed]["nuclear"]
        require(type(nuclear["iterations"]) is int and 1 <= nuclear["iterations"] <= 10000, label + " ADMM iterations")
        require(all(np.isfinite(nuclear[name]) and nuclear[name] >= 0 for name in ("primal_residual", "dual_residual", "objective")), label + " ADMM fields")
        converged = nuclear["primal_residual"] < 1e-6 and nuclear["dual_residual"] < 1e-6
        require(nuclear["converged"] is converged, label + " ADMM flag")
        objective = float(0.5 * np.sum((arrays["nuclear_P"] @ b - y) ** 2) + np.linalg.svd(arrays["nuclear_P"], compute_uv=False).sum())
        close(objective, nuclear["objective"], label + " ADMM objective")
        max_objective_error = max(max_objective_error, abs(objective - nuclear["objective"]))
        if not converged:
            require(nuclear["iterations"] == 10000, label + " cap reached")
            admm_failures.append({"k": k, "seed": seed, "diagnostics": nuclear})
        upper = np.triu_indices(40, 1)
        groups = b.argmax(axis=1)
        directed = y[:, groups]
        count_product = directed * directed.T
        explicit = np.array([y[i, groups[j]] * y[j, groups[i]] for i, j in zip(*upper)])
        require(np.array_equal(count_product[upper], explicit), label + " count-product definition")
        labels = a[upper]
        row = {"k": k, "seed": seed}
        for model, name in AUC_MODELS.items():
            scores = count_product[upper] if name is None else arrays[name][upper]
            value = auc_pair(labels, scores)
            rank = auc_rank(labels, scores)
            close(value, rank, label + " independent AUC " + model, atol=1e-12, rtol=0)
            max_auc_error = max(max_auc_error, abs(value - rank))
            if model in MODELS:
                close(value, records[k, seed, model]["auc"], label + " saved AUC " + model, atol=1e-12, rtol=0)
            row[model] = value
        excluded = (directed[upper] == 0) | (directed.T[upper] == 0)
        require(np.all(labels[excluded] == 0), label + " zero excludes only nonedges")
        row["nonedges_excluded_by_zero_fraction"] = float(excluded[labels == 0].mean())
        zero_score = (~excluded).astype(float)
        row["zero_only_auc"] = auc_pair(labels, zero_score)
        zero_rank = auc_rank(labels, zero_score)
        close(row["zero_only_auc"], zero_rank, label + " zero AUC", atol=1e-12, rtol=0)
        max_auc_error = max(max_auc_error, abs(row["zero_only_auc"] - zero_rank))
        close(row["zero_only_auc"], 0.5 + 0.5 * row["nonedges_excluded_by_zero_fraction"], label + " zero identity", atol=1e-12, rtol=0)
        auc_rows.append(row)
    for table in (data["summary"], read_csv(results_dir / "summary.csv")):
        index = unique(table, ("k", "model"))
        require(len(index) == 6, "six marginal summaries")
        seen = set()
        for row in table:
            key = int(row["k"]), row["model"]
            require(key in set(itertools.product(KS, MODELS)) and key not in seen, "summary key")
            seen.add(key)
            require(int(row["replicates"]) == 40, "summary replicates")
            for metric in (*METRICS, "seconds"):
                values = [records[key[0], s, key[1]][metric] if metric == "seconds" else recomputed[key[0], s, key[1]][metric] for s in SEEDS]
                stats = describe(values)
                for field in ("mean", "sd"):
                    close(float(row[metric + "_" + field]), stats[field], "summary " + metric + " " + field)
    labels = {"Bayes_circle": "Circular Bayes", "Nuclear_probability": "Nuclear-norm comparator", "Density": "Constant density"}
    tex_rows = [f"{r['k']} & {labels[r['model']]} & " + " & ".join(f"{r[m + '_mean']:.3f} ({r[m + '_sd']:.3f})" for m in METRICS) + r" \\" for r in data["summary"]]
    stored_tex = (results_dir / "results_table.tex").read_text()
    require(all(stored_tex.count(row) == 1 for row in tex_rows), "rounded table rows")
    paired = [{"cohort": key[0], "k": key[1], "comparison": key[2], "metric": key[3], **value} for key, value in paired_summaries(recomputed).items()]
    require(len(paired) == 135, "paired summary count")
    validation = {"runs": 80, "graphs": 40, "estimators_unchanged": True,
                  "all_saved_metrics_recomputed": True, "all_nested_inputs_verified": True,
                  "mcmc_failed_screens": mcmc_failures,
                  "mcmc_max_rhat": max(v["split_rhat"] for v in scalar_diagnostics),
                  "mcmc_min_ess": min(v["ess_initial_positive"] for v in scalar_diagnostics),
                  "admm_failed": admm_failures, "runtime_seconds": metadata["total_seconds"], "scope": SCOPE,
                  "checks": {"method_records": 240, "metric_values": 720, "paired_summary_rows": 135,
                             "scalar_trace_series": 240, "scalar_diagnostic_values": 480,
                             "auc_pair_rank_values": 480, "zero_identity_graph_design_pairs": 80,
                             "max_metric_absolute_error": max_metric_error,
                             "max_scalar_diagnostic_absolute_error": max_scalar_error,
                             "max_objective_absolute_error": max_objective_error,
                             "max_pair_rank_auc_absolute_error": max_auc_error,
                             "all_probability_constraints_verified": True,
                             "rounded_saved_table_verified": True,
                             "execution_within_original_timeout": metadata["total_seconds"] < protocol["timeout_seconds"]},
                  "limits": ["ADMM residuals and stopping flags are checked for consistency; unsaved ADMM iterates cannot be independently reconstructed without refitting.",
                             "Acceptance fractions and proposal scales are range-checked; unsaved proposal histories cannot be independently reconstructed.",
                             "This postprocessor never executes estimators; fresh-execution identity is bound by the run contract and runner hashes."]}
    summaries, paired_auc = [], []
    for cohort, seeds in (("original4", SEEDS[:4]), ("all40", SEEDS)):
        for k in KS:
            subset = [r for r in auc_rows if r["k"] == k and r["seed"] in seeds]
            for model in AUC_MODELS:
                summaries.append({"cohort": cohort, "k": k, "model": model, **describe([r[model] for r in subset])})
            for left, right in AUC_PAIRS:
                values = [r[left] - r[right] for r in subset]
                paired_auc.append({"cohort": cohort, "k": k, "comparison": left + " minus " + right,
                                   **describe(values), "positive_graphs": sum(v > 0 for v in values),
                                   "negative_graphs": sum(v < 0 for v in values)})
    array_hashes = {name: sha256(results_dir / name) for name in sorted(expected_npz)}
    auc_output = {"source_results_sha256": sha256(results_dir / "results.json"),
                  "source_arrays_manifest_sha256": manifest_digest(array_hashes),
                  "scope": SCOPE + " Count product is an uncalibrated ranking score, not a probability estimator. Diagnostics are recomputed from the new arrays.",
                  "all_saved_auc_match": True, "two_auc_implementations_agree": True,
                  "summary": summaries, "paired_differences": paired_auc, "runs": auc_rows,
                  "zero_only_summary": {str(k): describe([r["zero_only_auc"] for r in auc_rows if r["k"] == k]) for k in KS}}
    return data, arrays_by_key, paired, validation, auc_output, array_hashes


def compare_baseline(baseline, data, arrays, paired, validation, auc_output, results_dir):
    original = read_json(baseline / "results/results.json")
    array_rows = []
    for (k, seed), fresh_arrays in arrays.items():
        with np.load(baseline / f"results/run_k{k}_seed{seed}.npz", allow_pickle=False) as archive:
            require(set(archive.files) == set(fresh_arrays), "baseline array keys")
            for name, fresh in fresh_arrays.items():
                old = archive[name]
                require(fresh.shape == old.shape and np.isfinite(old).all(), "baseline array shape/finite")
                array_rows.append({"k": k, "seed": seed, "array": name, "elements": int(fresh.size),
                                   "dtype_equal": fresh.dtype == old.dtype,
                                   "exact_equal": bool(np.array_equal(fresh, old)),
                                   "different_elements": int(np.count_nonzero(fresh != old)),
                                   "max_absolute_error": float(np.max(np.abs(fresh - old)))})
    def records_without_time(source):
        return [{key: value for key, value in row.items() if key != "seconds"} for row in source["runs"]]
    def summaries_without_time(source):
        return [{key: value for key, value in row.items() if not key.startswith("seconds_")} for row in source["summary"]]
    old_paired = read_csv(baseline / "paired-summary.csv")
    old_paired = [{**r, "n": int(r["n"]), **{f: float(r[f]) for f in ("mean", "sd", "mcse")}} for r in old_paired]
    old_paired_index = unique(old_paired, ("cohort", "k", "comparison", "metric"))
    old_paired = [old_paired_index[tuple(row[f] for f in ("cohort", "k", "comparison", "metric"))] for row in paired]
    old_auc = read_json(baseline / "auc-diagnostics/results.json")
    auc_fields = ("all_saved_auc_match", "two_auc_implementations_agree", "summary", "paired_differences", "runs", "zero_only_summary")
    scientific = {
        "metadata": compare_values({k: v for k, v in data["metadata"].items() if k not in RUNTIME_KEYS}, {k: v for k, v in original["metadata"].items() if k not in RUNTIME_KEYS}),
        "method_records": compare_values(records_without_time(data), records_without_time(original)),
        "marginal_summaries": compare_values(summaries_without_time(data), summaries_without_time(original)),
        "all_fit_diagnostics": compare_values(data["diagnostics"], original["diagnostics"]),
        "paired_summary": compare_values(paired, old_paired),
        "auc_diagnostics": compare_values({k: auc_output[k] for k in auc_fields}, {k: old_auc[k] for k in auc_fields}),
    }
    rounded_changes = []
    old_summary = unique(original["summary"], ("k", "model"))
    for row in data["summary"]:
        previous = old_summary[row["k"], row["model"]]
        for metric in METRICS:
            a = f"{row[metric + '_mean']:.3f} ({row[metric + '_sd']:.3f})"
            b = f"{previous[metric + '_mean']:.3f} ({previous[metric + '_sd']:.3f})"
            if a != b:
                rounded_changes.append({"k": row["k"], "model": row["model"], "metric": metric, "fresh": a, "baseline": b})
    paired_rounded_changes = []
    for row, previous in zip(paired, old_paired):
        for field in ("mean", "mcse"):
            a, b = f"{row[field]:.4f}", f"{previous[field]:.4f}"
            if a != b:
                paired_rounded_changes.append({**{key: row[key] for key in ("cohort", "k", "comparison", "metric")},
                                               "field": field, "fresh": a, "baseline": b})
    auc_rounded_changes = []
    old_auc_summary = unique(old_auc["summary"], ("cohort", "k", "model"))
    auc_current = list(auc_output["summary"]) + [{"cohort": "all40", "k": int(k), "model": "zero_only_auc", **r}
                                                for k, r in auc_output["zero_only_summary"].items()]
    old_auc_summary.update({("all40", int(k), "zero_only_auc"): r for k, r in old_auc["zero_only_summary"].items()})
    for row in auc_current:
        previous = old_auc_summary[row["cohort"], row["k"], row["model"]]
        for field, precision in (("mean", 3), ("sd", 3), ("mcse", 4)):
            a, b = f"{row[field]:.{precision}f}", f"{previous[field]:.{precision}f}"
            if a != b:
                auc_rounded_changes.append({**{key: row[key] for key in ("cohort", "k", "model")},
                                            "field": field, "precision": precision, "fresh": a, "baseline": b})
    caps = lambda rows: [{"k": r["k"], "seed": r["seed"]} for r in rows if not r["nuclear"]["converged"]]
    old_caps, new_caps = caps(original["diagnostics"]), caps(data["diagnostics"])
    timings = []
    old_runs = unique(original["runs"], ("k", "seed", "model"))
    for row in data["runs"]:
        previous = old_runs[row["k"], row["seed"], row["model"]]
        timings.append({"k": row["k"], "seed": row["seed"], "model": row["model"],
                        "baseline_seconds": previous["seconds"], "fresh_seconds": row["seconds"],
                        "difference_seconds": row["seconds"] - previous["seconds"]})
    return {"schema_version": 1, "scope": SCOPE,
            "baseline_results_sha256": sha256(baseline / "results/results.json"),
            "fresh_results_sha256": sha256(results_dir / "results.json"),
            "scientific_exact_equal": all(r["exact_equal"] and r["dtype_equal"] for r in array_rows) and all(s["exact_equal"] for s in scientific.values()),
            "array_comparison": {"arrays_compared": len(array_rows), "elements_compared": sum(r["elements"] for r in array_rows),
                                 "all_exact_equal": all(r["exact_equal"] and r["dtype_equal"] for r in array_rows),
                                 "max_absolute_error": max(r["max_absolute_error"] for r in array_rows),
                                 "by_array_name": {name: {"arrays": sum(r["array"] == name for r in array_rows),
                                                          "all_exact_equal": all(r["exact_equal"] and r["dtype_equal"] for r in array_rows if r["array"] == name),
                                                          "max_absolute_error": max(r["max_absolute_error"] for r in array_rows if r["array"] == name)}
                                                   for name in sorted(arrays[4, 101])}, "per_array": array_rows},
            "scientific_json": scientific,
            "rounded_table": {"precision": 3, "changed_cells": rounded_changes,
                              "paired_mean_mcse_precision4_changes": paired_rounded_changes,
                              "auc_mean_sd_precision3_mcse_precision4_changes": auc_rounded_changes,
                              "tex_byte_identical": (results_dir / "results_table.tex").read_bytes() == (baseline / "results/results_table.tex").read_bytes()},
            "iteration_caps": {"baseline": old_caps, "fresh": new_caps,
                               "definition": "Fits failing the residual criterion, retained at the 10000 iteration cap.",
                               "baseline_all_reaching_cap": [{"k": r["k"], "seed": r["seed"], "converged": r["nuclear"]["converged"]} for r in original["diagnostics"] if r["nuclear"]["iterations"] == 10000],
                               "fresh_all_reaching_cap": [{"k": r["k"], "seed": r["seed"], "converged": r["nuclear"]["converged"]} for r in data["diagnostics"] if r["nuclear"]["iterations"] == 10000],
                               "added": [r for r in new_caps if r not in old_caps], "removed": [r for r in old_caps if r not in new_caps]},
            "timings_and_environment": {"excluded_from_scientific_equality": True,
                                        "baseline": {k: original["metadata"][k] for k in sorted(RUNTIME_KEYS)},
                                        "fresh": {k: data["metadata"][k] for k in sorted(RUNTIME_KEYS)},
                                        "total_seconds_difference": data["metadata"]["total_seconds"] - original["metadata"]["total_seconds"],
                                        "per_method_run": timings},
            "validation_baseline": read_json(baseline / "validation.json"),
            "validation_fresh": validation}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run-contract", type=Path, required=True)
    parser.add_argument("--runner", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--baseline-dir", type=Path)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    contract = read_json(args.run_contract)
    protocol = contract.get("original_protocol", contract)
    require(sha256(args.runner) == protocol["runner_sha256"], "runner contract hash")
    require(sha256(args.reference) == protocol["source_sha256"], "reference contract hash")
    data, arrays, paired, validation, auc_output, array_hashes = verify_arrays(args.results_dir, protocol)
    content = io.StringIO(newline="")
    writer = csv.DictWriter(content, fieldnames=("cohort", "k", "comparison", "metric", "n", "mean", "sd", "mcse"))
    writer.writeheader()
    writer.writerows(paired)
    outputs = {"paired-summary.csv": content.getvalue().encode(), "validation.json": json_bytes(validation),
               "auc-diagnostics/results.json": json_bytes(auc_output)}
    if args.baseline_dir:
        comparison = compare_baseline(args.baseline_dir, data, arrays, paired, validation, auc_output, args.results_dir)
        outputs["comparison.json"] = json_bytes(comparison)
    source_files = {name: sha256(args.results_dir / name) for name in ("results.json", "runs.csv", "summary.csv", "results_table.tex")}
    provenance = {"schema_version": 1, "scope": SCOPE, "source_kind": "fresh-run files, not the old submitted ZIP",
                  "postprocessor_sha256": sha256(Path(__file__)), "runner_sha256": sha256(args.runner),
                  "reference_sha256": sha256(args.reference), "run_contract_sha256": sha256(args.run_contract),
                  "source_files": source_files, "source_arrays": array_hashes,
                  "source_arrays_manifest_sha256": manifest_digest(array_hashes),
                  "outputs": {name: sha256(args.output_dir / name) if args.verify_only else hashlib.sha256(raw).hexdigest()
                              for name, raw in outputs.items() if name != "comparison.json"},
                  "verification_limits": validation["limits"]}
    outputs["PROVENANCE.json"] = json_bytes(provenance)
    if args.verify_only:
        for name, raw in outputs.items():
            path = args.output_dir / name
            if name.endswith(".json"):
                require_recomputed_equal(json.loads(raw), read_json(path), name)
            else:
                rows = read_csv(path)
                require(len(rows) == len(paired), "saved paired CSV row count")
                for row, expected in zip(rows, paired):
                    parsed = {**row, "n": int(row["n"]), **{f: float(row[f]) for f in ("mean", "sd", "mcse")}}
                    require_recomputed_equal(parsed, expected, "paired CSV")
    else:
        require(not args.output_dir.exists(), "output directory already exists; use --verify-only")
        args.output_dir.mkdir(parents=True)
        for name, raw in outputs.items():
            path = args.output_dir / name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("xb") as handle:
                handle.write(raw)
    print(json.dumps({"status": "PASS", "mode": "verify-only" if args.verify_only else "create",
                      "method_records": 240, "metrics_recomputed": 720, "paired_summary_rows": 135,
                      "auc_pair_rank_checks": 480, "mcmc_failed_screens": validation["mcmc_failed_screens"],
                      "mcmc_max_rhat": validation["mcmc_max_rhat"], "mcmc_min_ess": validation["mcmc_min_ess"],
                      "admm_capped_retained": [{"k": r["k"], "seed": r["seed"]} for r in validation["admm_failed"]],
                      "comparison_included": bool(args.baseline_dir), "estimator_calls": 0}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, OSError, TypeError) as error:
        print("FAIL:", error, file=sys.stderr)
        raise SystemExit(1)

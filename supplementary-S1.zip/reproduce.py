"""Run the fixed experiment into a new directory; never overwrite saved data."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone


def main():
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        help="new, nonexistent output directory outside this package")
    args = parser.parse_args()
    output = (args.output if args.output is not None else root.parent /
              ("replication-rerun-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))).resolve()
    if output == root or root in output.parents:
        parser.error("output must be outside the saved replication package")
    if output.exists():
        parser.error("output already exists; choose a new directory")
    contract = json.loads((root / "CONTRACT.json").read_text(encoding="utf-8"))
    environment = os.environ.copy()
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        environment[name] = "1"
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    # Reserve the directory before starting; the exact runner writes only here.
    output.mkdir(parents=True, exist_ok=False)
    command = [sys.executable, str(root / "run_experiment.py"), "--output", str(output),
               "--warmup", str(contract["warmup"]), "--draws", str(contract["draws"])]
    print("New results directory:", output, flush=True)
    print("Fixed 600-second execution cap; no selective retry or exclusion.", flush=True)
    try:
        completed = subprocess.run(command, env=environment,
                                   timeout=contract["timeout_seconds"], check=False)
        return completed.returncode
    except subprocess.TimeoutExpired:
        print("Execution cap reached. Partial output retained; no automatic retry.", file=sys.stderr)
        return 124


if __name__ == "__main__":
    raise SystemExit(main())

ARD reconstruction: fixed study, JSPI r4 diagnostic revision
Study executed October 14, 2026; r4 adds diagnostics of its saved arrays only.

QUICK VERIFICATION
Python 3.9+ and NumPy are required for the numeric checks. The saved execution
used Python 3.12.14 and NumPy 2.3.5; metadata is in results/results.json.
From this directory, run:

    python3 verify_all.py

The command also works by absolute filename from another working directory.
It reads saved files, validates their hashes, independently rescores all saved
arrays and scalar traces, and checks derived summaries. It does not generate
graphs, fit estimators, or write files. ReportLab is needed only to redraw the
figure, not for this numeric verification.

DESIGN AND EXECUTION
The same forty seeds are used: 101, 202, 303, 404, and 1001 through 1036. Each
graph has n=40 and is observed at K=4 and K=8 nested balanced partitions.
There are forty independent graphs and eighty graph/design combinations.
The original-four/extension-36 distinction records the original study design.
This complete rerun does not add forty independent replicates.

CONTRACT.json preserves the original fixed protocol and source hashes.
run_experiment.py and reference_implementation.py are unchanged. The circular
model uses the generating geometry and strength 1.5; matching observed counts
and memberships does not equalize structural information. Two MCMC chains
each use 400 warmup and 800 kept sweeps. ADMM uses rho=2, penalty=1, tolerance
1e-6 and an iteration cap of 10000. Numerical thread counts are one.

EXECUTION.json records the new start/end and wrapper status. The scientific
runner reports 255.35019666699736 seconds; wrapper elapsed time is slightly
longer. Those timings are environment-specific observations.

All eighty graph/design fits completed. Six K=4 ADMM fits (seeds 1006, 1011,
1019, 1026, 1031, 1032) did not satisfy both residual tolerances before the cap.
They are retained. All eighty scalar MCMC screens pass, with maximum classic
split R-hat 1.0211420921060868 and minimum initial-monotone-sequence ESS 198.77062993327388.
The verifier computes these outcomes; it does not require this historical
failure list or zero MCMC failures as a condition for reporting new outcomes.

POST HOC RANKING SCORES
The count-product, true-P and zero-only comparisons were introduced after
the original study. They are recomputed here on the regenerated graphs and
refitted estimates. Re-execution does not make their selection predeclared
or create an independent validation set.

Count product is Y[i,g(j)] * Y[j,g(i)]. Zero-only is one if both counts are
positive and zero otherwise. Every real edge scores one in the zero-only
rule; AUC equals 0.5 + 0.5 times the excluded-nonedge fraction. These are
ranking scores, not calibrated edge probabilities. True-P uses generating
information and is not an AUC ceiling for count-conditioned reconstruction.

CONTENTS
results/: 80 NPZ files, results.json, runs.csv, summary.csv and result table.
checks/: independently recomputed 135-row paired summary, validation.json,
    AUC/zero-only diagnostic, provenance and fresh-versus-baseline comparison.
paired-summary.csv and validation.json: copies provided for summary tooling.
review-derived-summaries.json: zero-only paired contrasts and RMSE ratios,
    calculated from the fresh per-graph records. Ratios are ratios of means.
postprocess_rerun.py: pure array/trace verification and optional comparison;
    does not call estimator or original scoring functions.
derive_review_summaries.py: standard-library summary calculation/check.
verify_all.py: manifest check and the two read-only verification entry points.
plot_probability_matrices.py: redraws the three probability panels and realized adjacency from the
    first prescribed graph, seed101/K8, in native node order on a shared [0,1]
    linear blue scale. Requires NumPy and ReportLab; never calls an estimator.
probability-matrices.pdf and figure-provenance.json: new figure and input,
    renderer and output hashes. This is a standalone figure, not a paper PDF.
reproduce.py: guarded optional execution into a nonexistent external folder.
SHA256.json: all package file hashes, excluding the manifest itself.

VERIFICATION BOUNDARIES
Numeric checks include 720 original metrics, 240 scalar trace diagnostics,
135 paired-summary rows, all six ranking-score AUCs on all eighty graph/design
pairs using pair-comparison and averaged ranks, zero exclusions and their AUC
identity, graph/count constraints, nested inputs, source hashes and complete
normalized CSV key coverage. Additional summary checks bind their JSON/CSV
inputs and recompute the zero-only contrasts and probability-error ratios.

The recorded comparison with the r2 archive found all 640 numerical arrays
(1,062,400 elements), scientific metrics and diagnostics exactly equal in
this environment. Run timing and metadata differ. checks/comparison.json
identifies the baseline. verify_all.py hashes this comparison record but
cannot reperform the comparison without the separate baseline arrays. To
recheck it, supply an extracted r2 S1 folder as --baseline-dir to
postprocess_rerun.py together with the normal fresh verification arguments.
The r2 baseline archive is separate and is not included in this package.

ADMM intermediate iterates and complete latent proposal histories were not
saved; final residual/flag consistency is checked, not independently rebuilt.
Scalar MCMC screens do not prove full exploration or calibrated uncertainty.
Same-seed equality is a computational reproducibility finding, not validation
of the scientific model or performance at other sample sizes/designs. Near
ties and machine arithmetic may behave differently in another environment.

OPTIONAL NEW EXECUTION
Only if a new full rerun is wanted, invoke reproduce.py --output <new-folder>.
The target must be new and outside this package; the fixed 600-second cap
applies, with no automatic retry. It regenerates and refits the original study.
Postprocess that new folder into another nonexistent output directory using
postprocess_rerun.py, supplying this CONTRACT.json and the exact runner/reference.
Do not overwrite the saved results or label a new execution with this run's
EXECUTION.json. The raw runner defaults to a local results directory, so use
the guarded reproduce.py entry point. New diagnostic/provenance outputs belong
with the new execution; this package remains a saved record.

All observations are synthetic. No personal or empirical network data are used.

R4 DIAGNOSTIC REVISION
The simulation arrays and estimator code remain those of the October 14
complete run. No graph was generated or estimator fitted for this revision.
score_exclusion_diagnostics.py reads those arrays independently and verifies
raw-score AUC, zero-adjusted-score AUC and AUC on nonexcluded pairs. It also
reports density/count descriptions, paired contrasts and zero-score ties.
score-exclusion-diagnostics.json binds inputs, every graph-level value and
summary. verify_all.py runs its read-only --check automatically.

Zero-adjusted scores and retained-pair AUC are distinct diagnostics. Nuclear
scores of exactly zero on seven true edges at K=4 leave ties after masking;
the retained-pair comparison avoids confusing that effect with ordering inside
the nonexcluded set. These quantities do not constitute a calibrated estimate
or a lower bound for the uncomputed conditional benchmark's realized AUC.

The label ess_initial_positive remains in the unchanged estimator and archived
JSON for compatibility. Its calculation includes a monotone adjustment of the
paired autocorrelations after positive-sequence truncation, and ESS is capped
at the number of retained draws. It is not rank-normalized bulk ESS.

verify_all.py tolerates unmanifested files whose exact basename is .DS_Store,
and the existing __pycache__ convention. Unknown extra files still fail, as do
missing or changed required files. A manifested .DS_Store remains hash-checked.
This prevents ordinary Finder metadata from breaking numeric verification
without weakening the scientific payload checks.

The figure now shows realized adjacency instead of the constant-density panel,
alongside true, circular and nuclear probability matrices at the same seed,
node order and [0,1] scale. Its input arrays are unchanged.

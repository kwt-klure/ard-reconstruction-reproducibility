#!/usr/bin/env python3
"""Post hoc exclusion/ranking diagnostics from saved r3 arrays; never fit or sample.

Python standard library plus NumPy only. Paths are supplied by the caller.
Create a new report with --output PATH, or recompute and compare a saved report
without modifying it with --check PATH. Existing outputs are never overwritten.
All AUCs use unordered off-diagonal pairs and exact ties receive half credit.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np


SIGN_TOLERANCE = 1e-12
AUC_CHECK_TOLERANCE = 1e-14
MODELS = ("TrueP", "Circular", "Nuclear", "Product")
VIEWS = ("raw", "zero_excluded", "retained_pairs")
PAIRS = (
    ("nuclearZ_minus_product", "Nuclear", "zero_excluded", "Product", "raw"),
    ("truePZ_minus_product", "TrueP", "zero_excluded", "Product", "raw"),
    ("nuclearZ_minus_nuclear", "Nuclear", "zero_excluded", "Nuclear", "raw"),
    ("remaining_trueP_minus_product", "TrueP", "retained_pairs", "Product", "retained_pairs"),
    ("remaining_nuclear_minus_product", "Nuclear", "retained_pairs", "Product", "retained_pairs"),
    ("remaining_trueP_minus_nuclear", "TrueP", "retained_pairs", "Nuclear", "retained_pairs"),
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def summarize(values: list[float]) -> dict:
    array = np.asarray(values, dtype=float)
    require(array.size > 1 and np.isfinite(array).all(), "Invalid summary values")
    sd = float(array.std(ddof=1))
    return {
        "n": int(array.size), "mean": float(array.mean()), "sd": sd,
        "mcse": sd / math.sqrt(array.size),
        "min": float(array.min()), "max": float(array.max()),
    }


def summarize_difference(values: list[float]) -> dict:
    array = np.asarray(values, dtype=float)
    return {
        **summarize(values),
        "sign_counts_exact": {
            "positive": int(np.count_nonzero(array > 0)),
            "zero": int(np.count_nonzero(array == 0)),
            "negative": int(np.count_nonzero(array < 0)),
        },
        "sign_counts_with_tolerance": {
            "positive": int(np.count_nonzero(array > SIGN_TOLERANCE)),
            "near_zero": int(np.count_nonzero(np.abs(array) <= SIGN_TOLERANCE)),
            "negative": int(np.count_nonzero(array < -SIGN_TOLERANCE)),
        },
    }


def auc_pairwise(labels: np.ndarray, scores: np.ndarray) -> float:
    """Direct positive-versus-negative comparisons, independent of ranks."""
    positives, negatives = scores[labels == 1], scores[labels == 0]
    require(positives.size > 0 and negatives.size > 0, "AUC needs both classes")
    greater = np.count_nonzero(positives[:, None] > negatives[None, :])
    tied = np.count_nonzero(positives[:, None] == negatives[None, :])
    return float((greater + 0.5 * tied) / (positives.size * negatives.size))


def auc_ranks(labels: np.ndarray, scores: np.ndarray) -> float:
    """Mann-Whitney rank sum with average ranks for exact tie groups."""
    order = np.argsort(scores, kind="stable")
    sorted_scores = scores[order]
    starts = np.r_[0, np.flatnonzero(sorted_scores[1:] != sorted_scores[:-1]) + 1]
    stops = np.r_[starts[1:], len(scores)]
    rank_sum = 0.0
    for start, stop in zip(starts, stops):
        average_rank = (float(start) + 1.0 + float(stop)) / 2.0
        rank_sum += average_rank * np.count_nonzero(labels[order[start:stop]] == 1)
    positive_n = np.count_nonzero(labels == 1)
    negative_n = np.count_nonzero(labels == 0)
    require(positive_n > 0 and negative_n > 0, "AUC needs both classes")
    return float((rank_sum - positive_n * (positive_n + 1) / 2) / (positive_n * negative_n))


def checked_auc(labels: np.ndarray, scores: np.ndarray, checks: list[float]) -> float:
    require(np.isfinite(scores).all(), "Nonfinite AUC scores")
    direct, ranked = auc_pairwise(labels, scores), auc_ranks(labels, scores)
    error = abs(direct - ranked)
    require(error <= AUC_CHECK_TOLERANCE, "Pairwise/rank AUC discrepancy")
    checks.append(error)
    return direct


def read_arrays(path: Path, n: int, k: int) -> dict:
    names = ("Y", "B", "hidden_A", "true_P", "bayes_P", "nuclear_P")
    with np.load(path, allow_pickle=False) as archive:
        arrays = {name: archive[name] for name in names}
    for name, array in arrays.items():
        shape = (n, k) if name in ("Y", "B") else (n, n)
        require(array.shape == shape and np.isfinite(array).all(), f"{path.name}: {name} shape/finiteness")
        require(np.all(array >= 0), f"{path.name}: {name} negative entries")
        if name not in ("Y", "B"):
            require(np.array_equal(array, array.T), f"{path.name}: {name} asymmetry")
            require(np.all(np.diag(array) == 0), f"{path.name}: {name} nonzero diagonal")
            require(np.all(array <= 1), f"{path.name}: {name} exceeds one")
    adjacency, roster, counts = arrays["hidden_A"], arrays["B"], arrays["Y"]
    require(np.isin(adjacency, (0, 1)).all(), f"{path.name}: adjacency not binary")
    require(np.isin(roster, (0, 1)).all(), f"{path.name}: roster not binary")
    require(np.all(roster.sum(axis=1) == 1), f"{path.name}: roster is not a partition")
    require(np.all(roster.sum(axis=0) == n / k), f"{path.name}: roster not balanced")
    require(np.array_equal(counts, adjacency @ roster), f"{path.name}: Y != A B")
    return arrays


def compute(results_dir: Path) -> dict:
    metadata_path = results_dir / "results.json"
    source = json.loads(metadata_path.read_text(encoding="utf-8"))
    metadata = source["metadata"]
    n, ks, seeds = int(metadata["n"]), metadata["k"], metadata["seeds"]
    require(n == 40 and ks == [4, 8] and len(seeds) == 40, "Expected saved r3 n=40, K=4/8, 40 seeds")
    require(len(set(seeds)) == len(seeds), "Repeated seed in metadata")
    filenames = {f"run_k{k}_seed{seed}.npz" for k in ks for seed in seeds}
    require({p.name for p in results_dir.glob("*.npz")} == filenames, "NPZ inventory differs from metadata")
    input_hashes = {"results.json": sha256(metadata_path)}
    input_hashes.update({name: sha256(results_dir / name) for name in sorted(filenames)})
    saved_raw = {}
    for row in source["runs"]:
        key = (row["k"], row["seed"], row["model"])
        require(key not in saved_raw, f"Duplicate saved metric key: {key}")
        saved_raw[key] = row["auc"]
    require(len(saved_raw) == 240, "Expected 240 saved original-method metric rows")
    i, j = np.triu_indices(n, 1)
    auc_checks, raw_metric_errors = [], []
    runs, reference_graphs = [], {}
    paired_graph_checks = 0
    for k in ks:
        for seed in sorted(seeds):
            filename = f"run_k{k}_seed{seed}.npz"
            arrays = read_arrays(results_dir / filename, n, k)
            adjacency, probability = arrays["hidden_A"], arrays["true_P"]
            if seed in reference_graphs:
                old_adjacency, old_probability = reference_graphs[seed]
                require(np.array_equal(adjacency, old_adjacency), f"Seed {seed}: graph changes across K")
                require(np.array_equal(probability, old_probability), f"Seed {seed}: true_P changes across K")
                paired_graph_checks += 1
            else:
                reference_graphs[seed] = (adjacency.copy(), probability.copy())
            groups = np.argmax(arrays["B"], axis=1)
            count = arrays["Y"]
            product = count[i, groups[j]] * count[j, groups[i]]
            retained = product > 0
            labels = adjacency[i, j].astype(int)
            edge_n = int(np.count_nonzero(labels))
            negative_n = int(np.count_nonzero(labels == 0))
            retained_negative_n = int(np.count_nonzero(retained & (labels == 0)))
            excluded = ~retained
            excluded_edge_n = int(np.count_nonzero(excluded & (labels == 1)))
            require(excluded_edge_n == 0, f"{filename}: a realized edge is excluded")
            require(retained_negative_n > 0 and edge_n > 0, f"{filename}: retained subset lacks both classes")
            scores = {
                "TrueP": probability[i, j], "Circular": arrays["bayes_P"][i, j],
                "Nuclear": arrays["nuclear_P"][i, j], "Product": product,
            }
            auc = {}
            positive_zero_counts = {}
            for model, score in scores.items():
                auc[model] = {
                    "raw": checked_auc(labels, score, auc_checks),
                    "zero_excluded": checked_auc(labels, score * retained, auc_checks),
                    "retained_pairs": checked_auc(labels[retained], score[retained], auc_checks),
                }
                positive_zero_counts[model] = int(np.count_nonzero(score[labels == 1] == 0))
            zero_only = checked_auc(labels, retained.astype(float), auc_checks)
            zero_identity = 1 - 0.5 * retained_negative_n / negative_n
            require(abs(zero_only - zero_identity) <= AUC_CHECK_TOLERANCE, "Zero-only AUC identity failed")
            require(auc["Product"]["raw"] == auc["Product"]["zero_excluded"], "Product changed under exclusion")
            for model, source_name in (("Circular", "Bayes_circle"), ("Nuclear", "Nuclear_probability")):
                require((k, seed, source_name) in saved_raw, "Missing saved metric key")
                error = abs(auc[model]["raw"] - saved_raw[(k, seed, source_name)])
                require(error <= AUC_CHECK_TOLERANCE, f"{filename}: saved {model} AUC differs")
                raw_metric_errors.append(error)
            nuclear = scores["Nuclear"]
            nuclear_total = float(nuclear.sum())
            nuclear_excluded_mass = float(nuclear[excluded].sum())
            require(nuclear_total > 0 and excluded.any(), f"{filename}: undefined exclusion mass diagnostic")
            expected_degrees = probability.sum(axis=1)
            runs.append({
                "k": k, "seed": seed, "input": filename, "auc": auc,
                "paired_differences": {
                    name: auc[left][left_view] - auc[right][right_view]
                    for name, left, left_view, right, right_view in PAIRS
                },
                "zero_only_auc": zero_only,
                "positive_edges_with_zero_score": positive_zero_counts,
                "counts": {
                    "unordered_pairs": len(i), "realized_edges": edge_n,
                    "nonedges": negative_n, "retained_pairs": int(retained.sum()),
                    "retained_nonedges": retained_negative_n,
                    "excluded_pairs": int(excluded.sum()), "excluded_edges": excluded_edge_n,
                    "retained_nonedge_fraction": retained_negative_n / negative_n,
                },
                "density": {
                    "trueP_offdiag_mean": float(scores["TrueP"].mean()),
                    "trueP_offdiag_min": float(scores["TrueP"].min()),
                    "trueP_offdiag_max": float(scores["TrueP"].max()),
                    "expected_degree_mean": float(expected_degrees.mean()),
                    "expected_degree_min": float(expected_degrees.min()),
                    "expected_degree_max": float(expected_degrees.max()),
                    "realized_mean_degree": 2 * edge_n / n,
                    "realized_edge_density": edge_n / len(i),
                    "Y_mean": float(count.mean()), "Y_zero_fraction": float(np.mean(count == 0)),
                    "Y_max": float(count.max()),
                },
                "nuclear_excluded": {
                    "mean": float(nuclear[excluded].mean()),
                    "max": float(nuclear[excluded].max()),
                    "sum": nuclear_excluded_mass, "total_unordered_sum": nuclear_total,
                    "mass_fraction": nuclear_excluded_mass / nuclear_total,
                },
            })
    # Verify that no input changed between the initial hash and completed read.
    require(all(sha256(results_dir / name) == digest for name, digest in input_hashes.items()), "An input changed during computation")
    summaries = []
    for k in ks:
        group = [run for run in runs if run["k"] == k]
        total_excluded_n = sum(run["counts"]["excluded_pairs"] for run in group)
        total_excluded_mass = sum(run["nuclear_excluded"]["sum"] for run in group)
        summaries.append({
            "k": k, "graph_replicates": len(group),
            "auc": {
                model: {view: summarize([run["auc"][model][view] for run in group]) for view in VIEWS}
                for model in MODELS
            },
            "paired_differences": {
                name: summarize_difference([run["paired_differences"][name] for run in group])
                for name, *_ in PAIRS
            },
            "zero_only_auc": summarize([run["zero_only_auc"] for run in group]),
            "positive_edges_with_zero_score": {
                model: sum(run["positive_edges_with_zero_score"][model] for run in group) for model in MODELS
            },
            "counts": {
                name: summarize([run["counts"][name] for run in group]) for name in group[0]["counts"]
            },
            "density": {
                "graph_summaries": {
                    name: summarize([run["density"][name] for run in group]) for name in group[0]["density"]
                },
                "trueP_offdiag_overall_min": min(run["density"]["trueP_offdiag_min"] for run in group),
                "trueP_offdiag_overall_max": max(run["density"]["trueP_offdiag_max"] for run in group),
                "expected_degree_overall_min": min(run["density"]["expected_degree_min"] for run in group),
                "expected_degree_overall_max": max(run["density"]["expected_degree_max"] for run in group),
                "Y_overall_max": max(run["density"]["Y_max"] for run in group),
            },
            "nuclear_excluded": {
                "per_graph_mean": summarize([run["nuclear_excluded"]["mean"] for run in group]),
                "pooled_pair_mean": total_excluded_mass / total_excluded_n,
                "per_graph_maximum": summarize([run["nuclear_excluded"]["max"] for run in group]),
                "overall_maximum": max(run["nuclear_excluded"]["max"] for run in group),
                "mass_fraction_mean_of_graph_ratios": summarize([run["nuclear_excluded"]["mass_fraction"] for run in group]),
                "mass_fraction_ratio_of_sums": total_excluded_mass / sum(run["nuclear_excluded"]["total_unordered_sum"] for run in group),
            },
        })
    return {
        "schema_version": 1,
        "analysis": "Post hoc zero-exclusion versus retained-pair ranking diagnostic of saved r3 arrays",
        "provenance": {
            "input_files_sha256": input_hashes,
            "script_sha256": sha256(Path(__file__)),
            "input_design": {"n": n, "k": ks, "seeds": seeds},
            "data_generation_or_fitting": False,
            "independent_graph_replicates": 40, "graph_design_combinations": 80,
        },
        "definitions": {
            "unit": "Unordered off-diagonal pairs i < j; all summaries give each graph equal weight unless explicitly pooled.",
            "product": "S_ij = Y[i,g(j)] * Y[j,g(i)], with g from the one-hot roster B.",
            "zero_exclusion": "Z_ij = 1{S_ij > 0}; zero_excluded evaluates score * Z on ALL pairs.",
            "retained_pairs": "AUC among Z=1 pairs only; both positive and negative classes must be present.",
            "circular": "Saved bayes_P array; no recomputation of the fitted estimator.",
            "ties": "Exact numerical score equality gets one-half credit; no tolerance is used to define AUC ties.",
            "sd_mcse": "Sample SD (ddof=1); MCSE = sample SD / sqrt(40), also for within-graph paired differences.",
            "paired_comparisons": {name: f"{left}.{left_view} minus {right}.{right_view}" for name, left, left_view, right, right_view in PAIRS},
            "sign_policy": {
                "absolute_tolerance": SIGN_TOLERANCE,
                "meaning": "Exact sign counts and a separate near-zero count are both reported. The tolerance changes only sign-count categorization, never stored differences, means, SDs, MCSEs, AUC ties, or rounding.",
            },
            "nuclear_excluded_mean": "Mean saved nuclear_P over excluded unordered pairs; graph means and a pair-weighted pooled mean are distinguished.",
            "nuclear_excluded_mass_fraction": "For each graph sum(nuclear_P[Z=0]) / sum(nuclear_P) on i<j. Mean of graph ratios differs from pooled ratio of sums.",
            "density": "Off-diagonal true-P ranges and means use i<j; expected degree is the off-diagonal row sum; realized mean degree is 2|E|/n. Y summaries include all n*K cells.",
        },
        "checks": {
            "all_saved_graphs_validated": len(runs),
            "Y_equals_hidden_A_times_B": True,
            "all_realized_edges_have_Z_one": True,
            "all_retained_subsets_have_both_classes": True,
            "exact_same_graph_and_trueP_across_K": paired_graph_checks,
            "auc_pairwise_vs_rank_evaluations": len(auc_checks),
            "auc_pairwise_vs_rank_max_absolute_difference": max(auc_checks),
            "auc_check_absolute_tolerance": AUC_CHECK_TOLERANCE,
            "saved_circular_and_nuclear_raw_auc_comparisons": len(raw_metric_errors),
            "saved_raw_auc_max_absolute_difference": max(raw_metric_errors),
            "zero_only_identity_checked_all_graphs": True,
            "product_unchanged_by_zero_exclusion_all_graphs": True,
            "inputs_unchanged_during_read": True,
        },
        "limitations": [
            "Post hoc diagnostics of the same saved 40 graph replicates at K=4/8; no new independent Monte Carlo sample or fitted estimator.",
            "Retained-pair AUC changes the evaluated pair subset; it is not directly interchangeable with all-pair AUC.",
            "The true-P score is the generating marginal edge probability, not the posterior probability conditional on the observed same-graph ARD counts.",
            "Observed AUCs establish neither a conditional benchmark lower bound nor a universal ranking or optimality claim.",
            "Masking changes the evaluated score and its AUC; these diagnostics do not identify the cause of differences between fitted estimators.",
            "Per-K MCSEs use the 40 graph replicates. K=4 and K=8 share graphs and must not be treated as 80 independent graphs.",
        ],
        "summaries": summaries,
        "runs": runs,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-dir", required=True, type=Path)
    destination = parser.add_mutually_exclusive_group(required=True)
    destination.add_argument("--output", type=Path, help="Exclusively create a new JSON report; refuse existing paths")
    destination.add_argument("--check", type=Path, help="Recompute and compare an existing JSON report without writing")
    args = parser.parse_args()
    if args.output is not None and args.output.exists():
        parser.error(f"Refusing to overwrite existing output: {args.output}")
    report = compute(args.results_dir)
    if args.check is not None:
        existing = json.loads(args.check.read_text(encoding="utf-8"))
        require(report == existing, "Saved report differs from recomputation")
        print("PASS: saved report equals independent recomputation; no files changed.")
    else:
        with args.output.open("x", encoding="utf-8") as stream:
            json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False)
            stream.write("\n")
        print(f"Created {args.output.name}: {len(report['runs'])} graph/design rows.")
    for summary in report["summaries"]:
        values = summary["auc"]
        print(f"K={summary['k']}: nuclearZ={values['Nuclear']['zero_excluded']['mean']:.9f}, "
              f"product={values['Product']['raw']['mean']:.9f}, "
              f"truePZ={values['TrueP']['zero_excluded']['mean']:.9f}; "
              f"retained nuclear={values['Nuclear']['retained_pairs']['mean']:.9f}, "
              f"product={values['Product']['retained_pairs']['mean']:.9f}")


if __name__ == "__main__":
    main()

"""Verify this complete saved reproduction without generating graphs or fitting."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    manifest = json.loads((ROOT / "SHA256.json").read_text())["files"]
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob("*")
              if p.is_file() and p.name != "SHA256.json" and "__pycache__" not in p.parts
              and (p.name != ".DS_Store" or str(p.relative_to(ROOT)) in manifest)}
    if set(manifest) != actual:
        raise ValueError("Package file inventory mismatch")
    for name, expected in manifest.items():
        path = ROOT / name
        if path.is_symlink() or not path.resolve().is_relative_to(ROOT):
            raise ValueError("Unsafe package member: " + name)
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError("Package hash mismatch: " + name)
    commands = [
        ["postprocess_rerun.py", "--results-dir", "results", "--output-dir", "checks",
         "--run-contract", "CONTRACT.json", "--runner", "run_experiment.py",
         "--reference", "reference_implementation.py", "--verify-only"],
        ["derive_review_summaries.py", "--replication-dir", ".",
         "--diagnostic-json", "checks/auc-diagnostics/results.json",
         "--check", "review-derived-summaries.json"],
        ["score_exclusion_diagnostics.py", "--results-dir", "results",
         "--check", "score-exclusion-diagnostics.json"],
    ]
    for command in commands:
        subprocess.run([sys.executable, *command], cwd=ROOT, check=True)
    print(json.dumps({"status": "PASS", "files_hashed": len(manifest),
                      "fresh_numerical_verification": True,
                      "comparison_record_hash_checked": True,
                      "baseline_arrays_rechecked": False,
                      "new_simulation_or_refit": False}, indent=2))


if __name__ == "__main__":
    main()

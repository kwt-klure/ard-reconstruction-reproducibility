"""Render the fixed first-seed illustration from saved arrays; no fitting.

Requires NumPy and ReportLab. The probability and adjacency panels use the same linear [0, 1]
color scale and original node order; row 1 is at the top.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from reportlab.pdfgen import canvas


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arrays", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--provenance", type=Path, required=True)
    args = parser.parse_args()
    keys = ["true_P", "bayes_P", "nuclear_P", "hidden_A"]
    titles = ["Generating probability", "Circular Bayes", "Nuclear norm", "Realized adjacency"]
    with np.load(args.arrays, allow_pickle=False) as z:
        values = [z[k] for k in keys]
    for a in values:
        if a.shape != (40, 40) or not np.isfinite(a).all() or not ((0 <= a) & (a <= 1)).all():
            raise ValueError("Expected four finite 40-by-40 probability matrices")
        if not (np.diag(a) == 0).all():
            raise ValueError("Expected zero diagonals")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    c = canvas.Canvas(str(args.output), pagesize=(710, 660), invariant=1)
    c.setTitle("Realized adjacency and probabilities: seed 101, n=40, K=8")
    c.setAuthor("")
    low = np.array([247, 251, 255]) / 255
    high = np.array([8, 48, 107]) / 255

    def color(value):
        return low + float(value) * (high - low)

    size = 250
    positions = [(45, 360), (355, 360), (45, 50), (355, 50)]
    for a, title, (x, y) in zip(values, titles, positions):
        c.setFillColorRGB(0.1, 0.1, 0.1)
        c.setFont("Helvetica", 12)
        c.drawCentredString(x + size / 2, y + size + 17, title)
        cell = size / 40
        for i in range(40):
            for j in range(40):
                c.setFillColorRGB(*color(a[i, j]))
                c.rect(x + j * cell, y + (39 - i) * cell, cell, cell, stroke=0, fill=1)
        c.setStrokeColorRGB(0.25, 0.25, 0.25)
        c.setLineWidth(0.5)
        c.rect(x, y, size, size, stroke=1, fill=0)
        c.setFillColorRGB(0.1, 0.1, 0.1)
        c.setFont("Helvetica", 9)
        for node in (1, 20, 40):
            c.drawCentredString(x + (node - 0.5) * cell, y - 14, str(node))
            c.drawRightString(x - 7, y + size - (node - 0.5) * cell - 3, str(node))
    bx, by, bh, bw = 643, 185, 270, 14
    for i in range(270):
        c.setFillColorRGB(*color((i + 0.5) / 270))
        c.rect(bx, by + i, bw, 1, stroke=0, fill=1)
    c.setFillColorRGB(0.1, 0.1, 0.1)
    c.setFont("Helvetica", 9)
    for value, label in ((0, "0"), (0.5, "0.5"), (1, "1")):
        c.drawString(bx + bw + 5, by + value * bh - 3, label)
    c.setFont("Helvetica", 9)
    c.drawCentredString(330, 11, "Original node order; common scale [0, 1]")
    c.showPage()
    c.save()
    h = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    record = {"input_file": args.arrays.name, "input_sha256": h(args.arrays),
              "renderer_sha256": h(Path(__file__)), "output_sha256": h(args.output),
              "arrays": keys, "n": 40, "k": 8, "seed": 101,
              "node_order": "original; row 1 at top", "color_scale": [0, 1],
              "simulation_or_fit_called": False}
    args.provenance.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()

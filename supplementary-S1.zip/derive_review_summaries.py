#!/usr/bin/env python3
"""Derive review checks from saved per-graph JSON; never simulate or refit.

Example (paths are supplied by the caller):
  python derive_review_summaries.py --replication-dir replication \
      --diagnostic-json replication/auc-diagnostics/results.json \
      --output review-derived-summaries.json
Replace --output with --check to verify an existing derived summary read-only.
Only the Python standard library is required. No saved graph arrays are read.
"""

import argparse
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import statistics


TOLERANCE = 1e-12
MODELS = ("Bayes_circle", "Nuclear_probability", "Density")
AUC_MODELS = ("True_P", "Count_product", *MODELS, "zero_only_auc")
AUC_PAIRS = (
    ("Bayes_circle", "zero_only_auc"),
    ("Count_product", "zero_only_auc"),
    ("Nuclear_probability", "zero_only_auc"),
    ("Bayes_circle", "True_P"),
)
RMSE_PAIRS = (("Nuclear_probability", "Density"), ("Bayes_circle", "Density"))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def stats(values, signed=False):
    values = list(values)
    require(len(values) >= 2, "MCSE requires at least two graphs")
    require(all(math.isfinite(x) for x in values), "Nonfinite metric")
    sd = statistics.stdev(values)
    result = {
        "n": len(values),
        "mean": statistics.mean(values),
        "sd": sd,
        "mcse": sd / math.sqrt(len(values)),
    }
    if signed:
        result.update(
            positive_graphs=sum(x > 0 for x in values),
            negative_graphs=sum(x < 0 for x in values),
            zero_graphs=sum(x == 0 for x in values),
        )
    return result


def unique_index(rows, fields):
    result = {tuple(row[field] for field in fields): row for row in rows}
    require(len(result) == len(rows), "Duplicate records for " + repr(fields))
    return result


def close(actual, expected, label):
    require(math.isfinite(actual) and math.isfinite(expected), label + ": nonfinite")
    require(abs(actual - expected) <= TOLERANCE, label + ": values disagree")
    return abs(actual - expected)


def derive(replication_dir, diagnostic_json):
    paths = {
        "replication_results": replication_dir / "results" / "results.json",
        "replication_paired_summary": replication_dir / "paired-summary.csv",
        "archived_auc_diagnostic": diagnostic_json,
    }
    raw = {role: path.read_bytes() for role, path in paths.items()}
    replication = json.loads(raw["replication_results"])
    diagnostic = json.loads(raw["archived_auc_diagnostic"])
    paired_csv = list(csv.DictReader(io.StringIO(raw["replication_paired_summary"].decode())))
    seeds = sorted(replication["metadata"]["seeds"])
    ks = sorted(replication["metadata"]["k"])
    require(ks == [4, 8] and len(seeds) == len(set(seeds)) == 40,
            "Expected the archived K=4,8, 40-graph-per-K design")
    source_index = unique_index(replication["runs"], ("k", "seed", "model"))
    diagnostic_index = unique_index(diagnostic["runs"], ("k", "seed"))
    csv_index = unique_index(paired_csv, ("cohort", "k", "comparison", "metric"))
    expected_graphs = {(k, seed) for k in ks for seed in seeds}
    require(set(diagnostic_index) == expected_graphs, "Diagnostic graph keys disagree")
    require(set(source_index) == {(k, seed, model) for k, seed in expected_graphs
                                  for model in MODELS}, "Replication graph keys disagree")

    csv_checks = []
    by_k = {}
    max_saved_auc_difference = 0.0
    for k in ks:
        rows = [diagnostic_index[k, seed] for seed in seeds]
        rmse_values = {
            model: [source_index[k, seed, model]["probability_rmse"] for seed in seeds]
            for model in MODELS
        }
        for row in rows:
            for model in MODELS:
                max_saved_auc_difference = max(
                    max_saved_auc_difference,
                    close(row[model], source_index[k, row["seed"], model]["auc"],
                          "Saved AUC " + repr((k, row["seed"], model))),
                )
            require(0 <= row["nonedges_excluded_by_zero_fraction"] <= 1,
                    "Excluded-nonedge fraction out of range")
        auc = {model: stats(row[model] for row in rows) for model in AUC_MODELS}
        auc_paired = {
            left + " minus " + right: stats((row[left] - row[right] for row in rows), True)
            for left, right in AUC_PAIRS
        }
        rmse = {model: stats(values) for model, values in rmse_values.items()}
        rmse_paired = {
            left + " minus " + right: stats(
                (a - b for a, b in zip(rmse_values[left], rmse_values[right])), True)
            for left, right in RMSE_PAIRS
        }
        identity_residuals = [row["zero_only_auc"] -
                              (0.5 + 0.5 * row["nonedges_excluded_by_zero_fraction"])
                              for row in rows]
        identity_max_error = max(abs(x) for x in identity_residuals)
        require(identity_max_error <= TOLERANCE, "Zero-only AUC identity failed")
        for model in MODELS:
            for metric, derived in [("auc", auc[model]), ("probability_rmse", rmse[model])]:
                saved = csv_index["all40", str(k), model, metric]
                require(int(saved["n"]) == derived["n"], "CSV n disagrees")
                error = max(close(derived[field], float(saved[field]), "CSV " + field)
                            for field in ("mean", "sd", "mcse"))
                csv_checks.append({"k": k, "model_or_difference": model,
                                   "metric": metric, "max_absolute_difference": error})
        for label, derived in rmse_paired.items():
            saved = csv_index["all40", str(k), label, "probability_rmse"]
            require(int(saved["n"]) == derived["n"], "CSV paired n disagrees")
            error = max(close(derived[field], float(saved[field]), "CSV paired " + field)
                        for field in ("mean", "sd", "mcse"))
            csv_checks.append({"k": k, "model_or_difference": label,
                               "metric": "probability_rmse", "max_absolute_difference": error})
        close(auc["zero_only_auc"]["mean"], diagnostic["zero_only_summary"][str(k)]["mean"],
              "Diagnostic zero-only summary")
        density_mean = rmse["Density"]["mean"]
        by_k[str(k)] = {
            "n_graphs": len(rows),
            "auc": auc,
            "nonedges_excluded_by_zero_fraction": stats(
                row["nonedges_excluded_by_zero_fraction"] for row in rows),
            "auc_paired_differences": auc_paired,
            "probability_rmse": rmse,
            "probability_rmse_paired_differences": rmse_paired,
            "probability_rmse_ratios_of_means": {
                "Nuclear_probability_over_Density": rmse["Nuclear_probability"]["mean"] / density_mean,
                "Bayes_circle_reduction_relative_to_Density_percent":
                    100 * (density_mean - rmse["Bayes_circle"]["mean"]) / density_mean,
            },
            "zero_only_identity_check": {
                "formula": "zero_only_auc = 0.5 + 0.5 * nonedges_excluded_by_zero_fraction",
                "graphs_checked": len(rows),
                "max_absolute_residual": identity_max_error,
                "passed": True,
            },
            "per_graph_derived_checks": [
                {
                    "seed": seed,
                    "zero_only_identity_residual": identity_residuals[i],
                    "auc_paired_differences": {
                        left + " minus " + right: rows[i][left] - rows[i][right]
                        for left, right in AUC_PAIRS
                    },
                    "probability_rmse_paired_differences": {
                        left + " minus " + right: rmse_values[left][i] - rmse_values[right][i]
                        for left, right in RMSE_PAIRS
                    },
                }
                for i, seed in enumerate(seeds)
            ],
        }

    return {
        "schema_version": 1,
        "scope": "Summaries of the fresh same-seed execution per-graph JSON records; this summarizer performs no graph generation, fitting, or graph-array reads.",
        "inputs": {
            role: {"sha256": hashlib.sha256(content).hexdigest(), "bytes": len(content)}
            for role, content in raw.items()
        },
        "diagnostic_fresh_source": {key: diagnostic[key] for key in ("source_results_sha256", "source_arrays_manifest_sha256")},
        "methods": {
            "cohort": "all40",
            "pairing": "same k and seed; left minus right before summarizing",
            "mcse": "sample standard deviation across graph-level values (ddof=1) divided by sqrt(n_graphs)",
            "ratios": "ratios of graph-level means, not means of per-graph ratios",
            "circular_relative_reduction": "100 * (mean density probability RMSE - mean circular probability RMSE) / mean density probability RMSE",
            "sign_counts": "strict signs of stored floating-point paired differences; zero means exactly zero",
            "comparison_absolute_tolerance": TOLERANCE,
        },
        "checks": {
            "expected_graph_keys_match": True,
            "replication_auc_matches_diagnostic": True,
            "replication_auc_max_absolute_difference": max_saved_auc_difference,
            "paired_csv_rows_checked": len(csv_checks),
            "paired_csv_checks": csv_checks,
        },
        "interpretation_limits": [
            "High zero-only AUC demonstrates a strong exclusion-based ranking benchmark on these archived graphs; it is not a causal decomposition or proof that a fitted model's AUC is mostly caused by zero exclusion.",
            "AUC scores the same realized graph that supplied the observed counts; these comparisons do not establish held-out graph prediction.",
            "True_P is a fixed pre-graph probability ranking benchmark, not an upper bound on the realized-graph AUC of count-conditioned methods.",
            "The zero-only identity is checked from saved diagnostic fields. This script does not independently recompute zero exclusions or AUC from graph arrays.",
        ],
        "by_k": by_k,
    }


def check_equal(actual, expected, trail="root"):
    """Ignore insignificant floating-point variation, but compare all content."""
    if isinstance(actual, dict):
        require(isinstance(expected, dict) and set(actual) == set(expected), trail + ": key mismatch")
        for key in actual:
            check_equal(actual[key], expected[key], trail + "." + key)
    elif isinstance(actual, list):
        require(isinstance(expected, list) and len(actual) == len(expected), trail + ": list mismatch")
        for i, (a, b) in enumerate(zip(actual, expected)):
            check_equal(a, b, trail + "[" + str(i) + "]")
    elif isinstance(actual, float):
        require(isinstance(expected, (int, float)) and not isinstance(expected, bool),
                trail + ": numeric type mismatch")
        close(actual, expected, trail)
    else:
        require(type(actual) is type(expected) and actual == expected, trail + ": value mismatch")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replication-dir", type=Path, required=True)
    parser.add_argument("--diagnostic-json", type=Path, required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--output", type=Path, help="Create a new derived JSON; refuses overwrite")
    mode.add_argument("--check", type=Path, help="Compare an existing derived JSON read-only")
    args = parser.parse_args()
    result = derive(args.replication_dir, args.diagnostic_json)
    if args.check:
        check_equal(result, json.loads(args.check.read_bytes()))
        print("PASS: saved derived summary matches the existing JSON inputs and paired CSV.")
    else:
        with args.output.open("x", encoding="utf-8") as handle:
            handle.write(json.dumps(result, indent=2, allow_nan=False) + "\n")
        print("Created derived summary from existing records only.")


if __name__ == "__main__":
    main()
